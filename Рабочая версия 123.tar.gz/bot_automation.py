#!/usr/bin/env python3
import os, asyncio, logging
from datetime import datetime
from telethon import TelegramClient, events
from telethon.tl.custom import Message
from telethon.tl.types import KeyboardButtonCallback, ReplyInlineMarkup
from telethon.tl import functions

API_ID = '27270483'
API_HASH = '054487666c6a886114b50b6210e8c051'
PHONE_NUMBER = '+79507380505'
BOT_USERNAME = '@apri1l_test_bot'
SESSION_NAME = 'telegram_session'
TRIGGER_MESSAGE = 'Появились новые перевозки'

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)
logging.getLogger('telethon').setLevel(logging.WARNING)

class TransportBookingBot:
    def __init__(self):
        self.client = None
        self.bot_entity = None
        self.last_keyboard = None
        self.last_message_id = None
        self.is_processing = False
        self.automation_state = None
        self.automation_start_time = None
        self.edit_counter = 0
        self.stats = {'triggers_detected': 0, 'buttons_clicked': 0, 'errors': 0, 'start_time': datetime.now()}

    async def initialize(self):
        logger.info('Инициализация...')
        self.client = TelegramClient(SESSION_NAME, API_ID, API_HASH)
        await self.client.start(phone=PHONE_NUMBER)
        logger.info('Подключено к Telegram')
        if BOT_USERNAME:
            try:
                self.bot_entity = await self.client.get_entity(BOT_USERNAME)
                logger.info(f'Подключен к боту: {BOT_USERNAME}')
            except Exception as e:
                logger.error(f'Ошибка: {e}')

    async def save_keyboard(self, message: Message):
        if message.reply_markup and isinstance(message.reply_markup, ReplyInlineMarkup):
            self.last_keyboard = message.reply_markup
            self.last_message_id = message.id

            # МОМЕНТАЛЬНОЕ ЛОГИРОВАНИЕ КНОПОК
            all_buttons = []
            for row in self.last_keyboard.rows:
                for button in row.buttons:
                    if isinstance(button, KeyboardButtonCallback):
                        all_buttons.append(button)

            if all_buttons:
                buttons_text = ''.join([f'[{btn.text}]' for btn in all_buttons])
                logger.info(f'💾 Сохранено {len(all_buttons)} кнопок: {buttons_text}')

    async def click_button(self, button: KeyboardButtonCallback, info: str = '') -> bool:
        if not self.last_message_id:
            return False
        try:
            logger.info(f'⚡ Нажатие: \'{button.text}\' {info}')
            await self.client(functions.messages.GetBotCallbackAnswerRequest(peer=self.bot_entity, msg_id=self.last_message_id, data=button.data))
            logger.info(f'✓ Нажата: \'{button.text}\'')
            self.stats['buttons_clicked'] += 1
            return True
        except Exception as e:
            logger.error(f'❌ Ошибка: {e}')
            self.stats['errors'] += 1
            return False

    async def continue_automation(self, message: Message):
        logger.info(f'🔄 {self.automation_state}, Edit#{self.edit_counter}')
        if self.automation_start_time and (datetime.now() - self.automation_start_time).total_seconds() > 5.0:
            logger.warning('⏱️ Таймаут')
            self.automation_state = None
            self.edit_counter = 0
            return
        try:
            if self.automation_state == 'waiting_list':
                # Ищем РЕЙС (кнопку без эмодзи списков/меню/настроек)
                for row in self.last_keyboard.rows:
                    for button in row.buttons:
                        if isinstance(button, KeyboardButtonCallback):
                            text_lower = button.text.lower()
                            # Пропускаем кнопки меню
                            if any(word in text_lower for word in ['список', 'меню', 'настройки', 'возврат', 'назад', 'мои перевозки']):
                                continue
                            # Это рейс! Нажимаем
                            logger.info(f'⚡ Рейс: \'{button.text}\'')
                            await self.click_button(button, '(РЕЙС)')
                            self.automation_state = 'waiting_details'
                            self.edit_counter = 0
                            return
                logger.warning('⚠️ Жду рейсы...')
            elif self.automation_state == 'waiting_details':
                self.edit_counter += 1
                if self.edit_counter < 2:
                    logger.info(f'⏳ Пропускаю edit #{self.edit_counter}')
                    return

                logger.info('📦 Ищу подтверждение...')
                for row in self.last_keyboard.rows:
                    for button in row.buttons:
                        if isinstance(button, KeyboardButtonCallback):
                            for kw in ['подтвердить', 'забронировать', 'оформить', 'взять']:
                                if kw in button.text.lower():
                                    logger.info(f'✅ Нашел: \'{button.text}\'')
                                    await self.click_button(button, '(БРОНИРОВАНИЕ)')
                                    self.automation_state = None
                                    self.edit_counter = 0
                                    logger.info('🎉 ЗАВЕРШЕНО!')
                                    return
        except Exception as e:
            logger.error(f'❌ {e}')
            self.automation_state = None
            self.edit_counter = 0

    async def process_new_transport(self, message: Message):
        if self.is_processing:
            return
        self.is_processing = True
        self.stats['triggers_detected'] += 1
        logger.info('='*60)
        logger.info(f'🚨 НОВЫЕ ПЕРЕВОЗКИ! (#{self.stats["triggers_detected"]})')
        logger.info('='*60)
        try:
            await asyncio.sleep(0.02)
            if self.last_keyboard:
                self.automation_state = 'waiting_list'
                self.automation_start_time = datetime.now()
                self.edit_counter = 0
                for row in self.last_keyboard.rows:
                    for button in row.buttons:
                        if isinstance(button, KeyboardButtonCallback):
                            await self.click_button(button, '(список)')
                            return
        finally:
            self.is_processing = False

    async def handle_message(self, message):
        if self.bot_entity and message.peer_id.user_id != self.bot_entity.id:
            return
        await self.save_keyboard(message)
        if message.text and TRIGGER_MESSAGE in message.text:
            await self.process_new_transport(message)
            return
        if self.automation_state:
            await self.continue_automation(message)

    async def run(self):
        await self.initialize()
        logger.info('='*60)
        logger.info('🤖 БОТ ЗАПУЩЕН (УСКОРЕННЫЙ + МОМЕНТАЛЬНЫЕ ЛОГИ)')
        logger.info('='*60)
        self.client.add_event_handler(lambda e: self.handle_message(e.message), events.NewMessage())
        self.client.add_event_handler(lambda e: self.handle_message(e.message), events.MessageEdited())
        await self.client.run_until_disconnected()

if __name__ == '__main__':
    asyncio.run(TransportBookingBot().run())
