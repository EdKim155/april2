# 🤖 Софт Автоматизации Telegram Bot

Автоматизация для быстрого бронирования перевозок через Telegram бота.

## 📁 Структура файлов

```
/root/automation/
├── bot_automation.py       # Основной скрипт автоматизации
├── config.py              # Конфигурация (задержки, стратегии)
├── .env                   # Переменные окружения (API ключи)
├── venv/                  # Виртуальное окружение Python
├── start_automation.sh    # Скрипт запуска
├── stop_automation.sh     # Скрипт остановки
├── watch_logs.sh          # Просмотр логов в реальном времени
├── automation.log         # Файл логов
└── telegram_session.session  # Сессия Telegram (создается при первом запуске)
```

## 🚀 Быстрый старт

### 1. Запуск бота

```bash
cd /root/automation
./start_automation.sh
```

### 2. Просмотр логов в реальном времени

```bash
./watch_logs.sh
```

Или:

```bash
tail -f /root/automation/automation.log
```

### 3. Остановка бота

```bash
./stop_automation.sh
```

## 📊 Команды для мониторинга

```bash
# Проверить, работает ли бот
ps aux | grep bot_automation

# Последние 50 строк логов
tail -50 /root/automation/automation.log

# Последние 100 строк логов
tail -100 /root/automation/automation.log

# Поиск ошибок в логах
grep -i "error" /root/automation/automation.log

# Поиск успешных бронирований
grep "успешно нажата" /root/automation/automation.log

# Статистика работы
grep "Статистика" /root/automation/automation.log | tail -10
```

## ⚙️ Настройка конфигурации

Отредактируйте файл `config.py`:

```python
CONFIG = {
    DELAY_AFTER_TRIGGER: 0.001,      # Задержка после обнаружения триггера
    DELAY_BETWEEN_CLICKS: 0.05,       # Задержка между нажатиями кнопок
    BUTTON_STRATEGY: 'first',         # Стратегия: 'first', 'all', 'custom'
    LOG_LEVEL: 'DEBUG',               # Уровень логирования
}
```

## 🔧 Устранение неполадок

### Бот не запускается

1. Проверьте логи:
   ```bash
   tail -50 /root/automation/automation.log
   ```

2. Проверьте, что сессия создана:
   ```bash
   ls -la /root/automation/*.session
   ```

3. Попробуйте запустить вручную для диагностики:
   ```bash
   cd /root/automation
   source venv/bin/activate
   python bot_automation.py
   ```

### Бот не видит кнопки

- Проверьте в логах наличие сообщения "Сохранена клавиатура"
- Убедитесь, что бот подключен к правильному боту (@apri1l_test_bot)

### Бот не реагирует на триггер

- Триггерное сообщение: "Появились новые перевозки"
- Проверьте логи на наличие "🎯 Обнаружен триггер"

## 📈 Мониторинг производительности

Бот логирует статистику каждые N событий:

```
📊 Статистика: 
  - Триггеров: 5
  - Кнопок нажато: 15
  - Ошибок: 0
  - Время работы: 0:15:30
```

## 🔄 Автозапуск при перезагрузке сервера

Создайте systemd сервис:

```bash
cat > /etc/systemd/system/automation.service << 'EOFSVC'
[Unit]
Description=Telegram Bot Automation
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/automation
ExecStart=/root/automation/venv/bin/python /root/automation/bot_automation.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOFSVC

# Включить автозапуск
systemctl enable automation.service

# Запустить сервис
systemctl start automation.service

# Проверить статус
systemctl status automation.service

# Просмотр логов systemd
journalctl -u automation.service -f
```

## 🛡️ Безопасность

- Файл `.env` содержит конфиденциальные данные (API ключи)
- Убедитесь, что права доступа установлены правильно:
  ```bash
  chmod 600 /root/automation/.env
  ```

## 📝 Логирование

Уровни логирования:
- **DEBUG**: Все детали (включая отладочную информацию)
- **INFO**: Основные события (запуск, бронирования)
- **WARNING**: Предупреждения
- **ERROR**: Ошибки

Измените уровень в `config.py`:
```python
'LOG_LEVEL': 'INFO'  # или DEBUG, WARNING, ERROR
```
