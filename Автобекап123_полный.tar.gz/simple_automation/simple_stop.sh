#!/bin/bash
# Скрипт остановки упрощенной автоматизации

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PID_FILE="$SCRIPT_DIR/simple_automation.pid"

echo "🛑 Остановка упрощенной автоматизации..."

if [ ! -f "$PID_FILE" ]; then
    echo "⚠️  PID файл не найден. Бот не запущен?"

    # Попытаемся найти процесс вручную
    PIDS=$(pgrep -f "simple_button_automation.py")
    if [ -n "$PIDS" ]; then
        echo "🔍 Найдены процессы: $PIDS"
        echo -n "Остановить их? (y/n): "
        read -r REPLY
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            kill $PIDS
            echo "✅ Процессы остановлены"
        fi
    else
        echo "❌ Процессы не найдены"
    fi
    exit 0
fi

PID=$(cat "$PID_FILE")

# Проверяем, запущен ли процесс
if ! ps -p "$PID" > /dev/null 2>&1; then
    echo "⚠️  Процесс с PID $PID не найден (возможно, уже остановлен)"
    rm -f "$PID_FILE"
    exit 0
fi

# Останавливаем процесс
echo "🔪 Отправка сигнала завершения процессу $PID..."
kill "$PID"

# Ждем завершения (максимум 5 секунд)
for i in {1..5}; do
    if ! ps -p "$PID" > /dev/null 2>&1; then
        echo "✅ Бот успешно остановлен"
        rm -f "$PID_FILE"
        exit 0
    fi
    sleep 1
done

# Если процесс не остановился, используем kill -9
echo "⚠️  Процесс не остановился. Принудительная остановка..."
kill -9 "$PID" 2>/dev/null
rm -f "$PID_FILE"
echo "✅ Бот принудительно остановлен"
