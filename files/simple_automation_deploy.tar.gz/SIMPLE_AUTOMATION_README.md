# 🔔 Упрощенная автоматизация - нажатие на кнопку

Этот скрипт автоматически нажимает **только** на кнопку "🔔Список прямых перевозок" при появлении триггера "Появились новые перевозки".

**Никаких дальнейших действий не выполняется** - просто одно нажатие кнопки и всё.

---

## 📋 Что делает скрипт?

1. ✅ Подключается к Telegram боту
2. ✅ Ждет триггерное сообщение: **"Появились новые перевозки"**
3. ✅ При появлении триггера ищет кнопку: **"🔔Список прямых перевозок"**
4. ✅ Нажимает на эту кнопку
5. ✅ Ждет следующего триггера

**Внимание:** В отличие от полной версии автоматизации, этот скрипт **НЕ** выполняет:
- ❌ Выбор конкретного рейса
- ❌ Просмотр деталей перевозки
- ❌ Бронирование/подтверждение

---

## 🚀 Быстрый старт

### 1. Запуск

```bash
chmod +x simple_start.sh simple_stop.sh
./simple_start.sh
```

### 2. Просмотр логов в реальном времени

```bash
tail -f simple_automation.log
```

### 3. Остановка

```bash
./simple_stop.sh
```

---

## 📊 Пример работы

Когда бот обнаруживает триггер, в логах вы увидите:

```
2025-11-10 12:30:00,123 - __main__ - INFO - ======================================================================
2025-11-10 12:30:00,123 - __main__ - INFO - 🚨 ТРИГГЕР ОБНАРУЖЕН! (#1)
2025-11-10 12:30:00,123 - __main__ - INFO - ======================================================================
2025-11-10 12:30:00,150 - __main__ - INFO - 🎯 Найдена целевая кнопка: "🔔Список прямых перевозок"
2025-11-10 12:30:00,151 - __main__ - INFO - ⚡ Нажатие на кнопку: "🔔Список прямых перевозок"
2025-11-10 12:30:00,345 - __main__ - INFO - ✅ Успешно нажата кнопка: "🔔Список прямых перевозок"
2025-11-10 12:30:00,345 - __main__ - INFO - 🎉 УСПЕШНО!
2025-11-10 12:30:00,345 - __main__ - INFO - ──────────────────────────────────────────────────────────────────────
2025-11-10 12:30:00,345 - __main__ - INFO - 📊 СТАТИСТИКА:
2025-11-10 12:30:00,345 - __main__ - INFO -    • Триггеров обнаружено: 1
2025-11-10 12:30:00,345 - __main__ - INFO -    • Кнопок нажато: 1
2025-11-10 12:30:00,345 - __main__ - INFO -    • Ошибок: 0
2025-11-10 12:30:00,345 - __main__ - INFO -    • Время работы: 0:05:23
2025-11-10 12:30:00,345 - __main__ - INFO - ──────────────────────────────────────────────────────────────────────
```

---

## ⚙️ Настройки

Откройте файл `simple_button_automation.py` и измените параметры в секции КОНФИГУРАЦИЯ:

```python
# Триггер для активации
TRIGGER_MESSAGE = 'Появились новые перевозки'

# Текст кнопки для нажатия
TARGET_BUTTON_TEXT = '🔔Список прямых перевозок'

# Задержка после обнаружения триггера (секунды)
DELAY_AFTER_TRIGGER = 0.05
```

**Важно:** Текст кнопки должен **точно совпадать** с текстом кнопки в боте, включая эмодзи!

---

## 🔧 Команды мониторинга

```bash
# Проверить, работает ли бот
ps aux | grep simple_button_automation

# Последние 50 строк логов
tail -50 simple_automation.log

# Поиск ошибок в логах
grep -i "error\|ошибка" simple_automation.log

# Поиск успешных нажатий
grep "Успешно нажата кнопка" simple_automation.log

# Статистика
grep "СТАТИСТИКА" simple_automation.log
```

---

## 🆚 Сравнение версий

| Функция | Полная версия<br/>`bot_automation.py` | Упрощенная версия<br/>`simple_button_automation.py` |
|---------|--------------------------------------|-----------------------------------------------------|
| Нажатие на "Список прямых перевозок" | ✅ | ✅ |
| Выбор конкретного рейса | ✅ | ❌ |
| Просмотр деталей | ✅ | ❌ |
| Бронирование | ✅ | ❌ |
| Скорость работы | ~1.0-1.5 сек | ~0.05-0.1 сек |
| Сложность | Высокая | Низкая |

---

## 🛡️ Безопасность

- Скрипт использует существующую сессию Telegram (`telegram_session.session`)
- Все API ключи хранятся в коде (убедитесь, что файл защищен)
- Рекомендуется установить права доступа:

```bash
chmod 600 simple_button_automation.py
chmod 600 telegram_session.session
```

---

## 🐛 Устранение неполадок

### Бот не нажимает на кнопку

1. **Проверьте логи:**
   ```bash
   tail -50 simple_automation.log
   ```

2. **Убедитесь, что текст кнопки совпадает:**
   - Откройте бота вручную
   - Посмотрите точный текст кнопки (с эмодзи)
   - Сравните с `TARGET_BUTTON_TEXT` в скрипте

3. **Проверьте, что триггер правильный:**
   - Найдите в логах строку "ТРИГГЕР ОБНАРУЖЕН"
   - Если нет - проверьте `TRIGGER_MESSAGE`

### Бот не запускается

1. **Проверьте, что сессия создана:**
   ```bash
   ls -la telegram_session.session*
   ```

2. **Проверьте зависимости:**
   ```bash
   pip3 list | grep telethon
   ```
   Должна быть установлена библиотека `telethon`

3. **Запустите вручную для диагностики:**
   ```bash
   python3 simple_button_automation.py
   ```

---

## 📝 Требования

- Python 3.7+
- Библиотека `telethon`
- Telegram сессия (файл `telegram_session.session`)

Установка зависимостей:
```bash
pip3 install telethon
```

---

## 📞 Дополнительная информация

- **Основано на:** `Рабочая версия 321.tar.gz`
- **Дата создания:** 2025-11-10
- **Версия:** 1.0 (Simple)
- **Назначение:** Только нажатие на кнопку "🔔Список прямых перевозок"

---

## 🔄 Автозапуск при перезагрузке (опционально)

Если нужно, чтобы бот автоматически запускался при перезагрузке системы:

### Для Linux (systemd):

```bash
cat > /etc/systemd/system/simple-automation.service << 'EOF'
[Unit]
Description=Simple Telegram Button Automation
After=network.target

[Service]
Type=simple
User=YOUR_USERNAME
WorkingDirectory=/path/to/april2
ExecStart=/usr/bin/python3 /path/to/april2/simple_button_automation.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Замените YOUR_USERNAME и /path/to/april2 на свои значения
# Затем:
sudo systemctl enable simple-automation.service
sudo systemctl start simple-automation.service
sudo systemctl status simple-automation.service
```

### Для macOS (launchd):

```bash
# Создайте файл ~/Library/LaunchAgents/com.simple.automation.plist
cat > ~/Library/LaunchAgents/com.simple.automation.plist << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.simple.automation</string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/bin/python3</string>
        <string>/path/to/april2/simple_button_automation.py</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>WorkingDirectory</key>
    <string>/path/to/april2</string>
    <key>StandardOutPath</key>
    <string>/path/to/april2/simple_automation.log</string>
    <key>StandardErrorPath</key>
    <string>/path/to/april2/simple_automation_error.log</string>
</dict>
</plist>
EOF

# Замените /path/to/april2 на реальный путь
# Затем:
launchctl load ~/Library/LaunchAgents/com.simple.automation.plist
```

---

**Готово! Теперь у вас есть простой и понятный скрипт для автоматического нажатия на кнопку.**
