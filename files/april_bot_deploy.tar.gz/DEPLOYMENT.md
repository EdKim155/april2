# 🚀 April Bot - Деплой завершен!

## ✅ Что уже сделано:

1. ✅ Остановлен старый бот на сервере
2. ✅ Все файлы перенесены на сервер в `/opt/april_bot`
3. ✅ Установлен PostgreSQL
4. ✅ Создана база данных `april_bot`
5. ✅ Создан пользователь БД `april_user`
6. ✅ Создан systemd service для автозапуска
7. ✅ Установлены все Python зависимости

## 🔧 Осталось сделать:

### Вариант 1: Автоматическая настройка (рекомендуется)

Запустите скрипт, который запросит необходимые данные и настроит все автоматически:

```bash
bash deploy/setup_env.sh
```

**Вам потребуется:**
- Токен Telegram бота (BOT_TOKEN)
- ID Google таблицы (GOOGLE_SHEET_ID)

### Вариант 2: Ручная настройка

Подключитесь к серверу и создайте .env файл:

```bash
ssh -i ~/.ssh/id_ed25519_aprel root@72.56.76.248
cd /opt/april_bot
nano .env
```

Вставьте следующее содержимое (заменив значения):

```env
BOT_TOKEN=ваш_токен_от_BotFather
DB_HOST=localhost
DB_PORT=5432
DB_NAME=april_bot
DB_USER=april_user
DB_PASSWORD=ваш_пароль
GOOGLE_SHEET_ID=id_вашей_таблицы
GOOGLE_CREDENTIALS_FILE=/opt/april_bot/credentials/perevoz-477307-34872f231d9b.json
GOOGLE_SHEET_NAME=Перевозки
SYNC_INTERVAL=10
TIMEZONE=Europe/Moscow
PUBLISH_HOUR=11
PUBLISH_MINUTE=30
LOG_LEVEL=INFO
MAX_BOOKINGS_PER_MINUTE=10
```

Затем обновите пароль в БД и запустите бота:

```bash
sudo -u postgres psql -c "ALTER USER april_user WITH PASSWORD 'ваш_пароль';"
systemctl enable april_bot
systemctl start april_bot
systemctl status april_bot
```

## 📊 Управление ботом

### Просмотр логов в реальном времени:
```bash
ssh -i ~/.ssh/id_ed25519_aprel root@72.56.76.248 'journalctl -u april_bot -f'
```

### Перезапуск:
```bash
ssh -i ~/.ssh/id_ed25519_aprel root@72.56.76.248 'systemctl restart april_bot'
```

### Проверка статуса:
```bash
ssh -i ~/.ssh/id_ed25519_aprel root@72.56.76.248 'systemctl status april_bot'
```

## 📖 Дополнительная информация

Смотрите `deploy/README.md` для полной документации по управлению ботом.

---

**Сервер:** 72.56.76.248  
**Директория:** /opt/april_bot  
**Service:** april_bot.service  
**БД:** PostgreSQL (april_bot)

