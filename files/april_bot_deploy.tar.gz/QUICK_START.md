# 🚀 Быстрый старт April Bot

## Текущий статус

✅ **Деплой завершен!** Бот готов к запуску.

⏳ **Осталось:** Настроить переменные окружения и запустить

---

## Запуск за 2 минуты

### Шаг 1: Запустите скрипт настройки

```bash
cd /Users/edgark/Desktop/april2
bash deploy/setup_env.sh
```

### Шаг 2: Введите данные

Скрипт запросит:
- **BOT_TOKEN** - получите у [@BotFather](https://t.me/BotFather)
- **GOOGLE_SHEET_ID** - ID вашей Google таблицы
- **DB_PASSWORD** - просто нажмите Enter для автогенерации

### Шаг 3: Готово! 🎉

Бот автоматически запустится и будет работать 24/7

---

## Проверка работы

```bash
# Статус
bash deploy/bot_control.sh status

# Логи в реальном времени
bash deploy/bot_control.sh logs

# Или напрямую через SSH
ssh -i ~/.ssh/id_ed25519_aprel root@72.56.76.248 'journalctl -u april_bot -f'
```

---

## Полезные команды

```bash
# Показать все команды
bash deploy/bot_control.sh

# Перезапуск
bash deploy/bot_control.sh restart

# Обновление кода на сервере
bash deploy/bot_control.sh update

# Резервная копия
bash deploy/bot_control.sh backup
```

---

## Что дальше?

После запуска бот будет:
- ✅ Автоматически запускаться при перезагрузке сервера
- ✅ Синхронизироваться с Google Sheets каждые 10 секунд
- ✅ Публиковать новые перевозки ежедневно в 11:30
- ✅ Вести логи всех операций

---

## Нужна помощь?

📖 Полная документация: `deploy/README.md`  
📋 Инструкции по деплою: `DEPLOYMENT.md`

**Сервер:** 72.56.76.248  
**Директория:** /opt/april_bot

